module ph.edu.dlsu.lbycpei.sudoku {
    requires javafx.controls;
    requires javafx.media;

    exports ph.edu.dlsu.lbycpei.sudoku;
    exports ph.edu.dlsu.lbycpei.sudoku.model;
    exports ph.edu.dlsu.lbycpei.sudoku.view;
    exports ph.edu.dlsu.lbycpei.sudoku.controller;
    exports ph.edu.dlsu.lbycpei.sudoku.utils;
}