package ph.edu.dlsu.lbycpei.sudoku.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

public class SudokuView {
    private GridPane sudokuGrid;
    private TextField[][] cells;
    private Button newGameButton;
    private Button solveButton;
    private Button checkButton;
    private ComboBox<String> difficultyComboBox;
    private Label statusLabel;
    private VBox root;

    public SudokuView() {
        initializeComponents();
        setupLayout();
        applyStyles();
    }

    private void initializeComponents() {
        // Initialize Sudoku grid
        sudokuGrid = new GridPane();
        cells = new TextField[9][9];

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                cells[i][j] = new TextField();
                cells[i][j].setPrefSize(50, 50);
                cells[i][j].setAlignment(Pos.CENTER);
                cells[i][j].setFont(Font.font("Arial", 16));

                // Add style classes for grid lines
                cells[i][j].getStyleClass().add("sudoku-cell");
                if (i % 3 == 2 && i != 8) cells[i][j].getStyleClass().add("bottom-thick");
                if (j % 3 == 2 && j != 8) cells[i][j].getStyleClass().add("right-thick");
                if (i % 3 == 0 && i != 0) cells[i][j].getStyleClass().add("top-thick");
                if (j % 3 == 0 && j != 0) cells[i][j].getStyleClass().add("left-thick");

                sudokuGrid.add(cells[i][j], j, i);
            }
        }

        // Initialize control buttons
        newGameButton = new Button("Play");
        solveButton = new Button("Solve");
        checkButton = new Button("Check");

        // Initialize difficulty selector
        difficultyComboBox = new ComboBox<>();
        difficultyComboBox.getItems().addAll("Easy", "Medium", "Hard");
        difficultyComboBox.setValue("Easy");

        // Initialize status label
        statusLabel = new Label("Welcome to Sudoku!");

        // Apply button styles
        newGameButton.getStyleClass().add("control-button");
        solveButton.getStyleClass().add("control-button");
        checkButton.getStyleClass().add("control-button");
        difficultyComboBox.getStyleClass().add("difficulty-combo");
        statusLabel.getStyleClass().add("status-label");
    }

    private void setupLayout() {
        // Control panel
        HBox controlPanel = new HBox(10);
        controlPanel.setAlignment(Pos.CENTER);
        controlPanel.getChildren().addAll(
                new Label("Difficulty:"), difficultyComboBox,
                newGameButton, solveButton, checkButton
        );

        // Main layout
        root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));
        root.getChildren().addAll(sudokuGrid, controlPanel, statusLabel);
    }

    private void applyStyles() {
        root.getStyleClass().add("root");
        sudokuGrid.getStyleClass().add("sudoku-grid");
    }

    public TextField getCell(int row, int col) {
        return cells[row][col];
    }

    public Button getNewGameButton() {
        return newGameButton;
    }

    public Button getSolveButton() {
        return solveButton;
    }

    public Button getCheckButton() {
        return checkButton;
    }

    public ComboBox<String> getDifficultyComboBox() {
        return difficultyComboBox;
    }

    public Label getStatusLabel() {
        return statusLabel;
    }

    public VBox getRoot() {
        return root;
    }

    public void updateCell(int row, int col, int value, boolean isInitial) {
        TextField cell = cells[row][col];
        cell.setText(value == 0 ? "" : String.valueOf(value));

        if (isInitial) {
            cell.setEditable(false);
            cell.getStyleClass().add("initial-cell");
        } else {
            cell.setEditable(true);
            cell.getStyleClass().removeAll("initial-cell", "error-cell");
            cell.getStyleClass().add("user-cell");
        }
    }

    public void highlightError(int row, int col) {
        cells[row][col].getStyleClass().add("error-cell");
    }

    public void clearErrors() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                cells[i][j].getStyleClass().remove("error-cell");
            }
        }
    }
}