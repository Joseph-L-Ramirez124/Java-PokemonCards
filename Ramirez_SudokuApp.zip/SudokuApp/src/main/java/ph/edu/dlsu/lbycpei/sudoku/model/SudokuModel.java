package ph.edu.dlsu.lbycpei.sudoku.model;

import java.util.*;

public class SudokuModel {
    private int[][] board;
    private int[][] solution;
    private boolean[][] initialCells;
    private static final int SIZE = 9;
    private static final int EMPTY = 0;

    public SudokuModel() {
        board = new int[SIZE][SIZE];
        solution = new int[SIZE][SIZE];
        initialCells = new boolean[SIZE][SIZE];
    }

    public void generatePuzzle(int difficulty) {
        // Generate a complete valid Sudoku solution
        generateCompleteSolution();

        // Copy solution to board
        copyArray(solution, board);

        // Remove cells based on difficulty (Easy: 40, Medium: 50, Hard: 60)
        int cellsToRemove = 40 + (difficulty * 10);
        removeCells(cellsToRemove);

        // Mark initial cells
        markInitialCells();
    }

    private void generateCompleteSolution() {
        clearArray(solution);
        fillDiagonalBoxes();
        solveSudoku(solution);
    }

    private void fillDiagonalBoxes() {
        for (int i = 0; i < SIZE; i += 3) {
            fillBox(solution, i, i);
        }
    }

    private void fillBox(int[][] arr, int row, int col) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
        Collections.shuffle(numbers);

        int index = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                arr[row + i][col + j] = numbers.get(index++);
            }
        }
    }

    private boolean solveSudoku(int[][] arr) {
        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (arr[row][col] == EMPTY) {
                    for (int num = 1; num <= 9; num++) {
                        if (isValidMove(arr, row, col, num)) {
                            arr[row][col] = num;
                            if (solveSudoku(arr)) {
                                return true;
                            }
                            arr[row][col] = EMPTY;
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    private void removeCells(int cellsToRemove) {
        Random random = new Random();
        int removed = 0;

        while (removed < cellsToRemove) {
            int row = random.nextInt(SIZE);
            int col = random.nextInt(SIZE);

            if (board[row][col] != EMPTY) {
                board[row][col] = EMPTY;
                removed++;
            }
        }
    }

    private void markInitialCells() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                initialCells[i][j] = (board[i][j] != EMPTY);
            }
        }
    }

    public boolean isValidMove(int row, int col, int num) {
        return isValidMove(board, row, col, num);
    }

    private boolean isValidMove(int[][] arr, int row, int col, int num) {
        // Temporarily store the current value
        int temp = arr[row][col];
        arr[row][col] = EMPTY; // Clear the cell to avoid self-conflict

        boolean valid = !isInRow(arr, row, num) &&
                !isInColumn(arr, col, num) &&
                !isInBox(arr, row - row % 3, col - col % 3, num);

        arr[row][col] = temp; // Restore the original value
        return valid;
    }

    private boolean isInRow(int[][] arr, int row, int num) {
        for (int col = 0; col < SIZE; col++) {
            if (arr[row][col] == num) {
                return true;
            }
        }
        return false;
    }

    private boolean isInColumn(int[][] arr, int col, int num) {
        for (int row = 0; row < SIZE; row++) {
            if (arr[row][col] == num) {
                return true;
            }
        }
        return false;
    }

    private boolean isInBox(int[][] arr, int startRow, int startCol, int num) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (arr[row + startRow][col + startCol] == num) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean makeMove(int row, int col, int num) {
        if (isInitialCell(row, col)) {
            return false;
        }

        board[row][col] = num;
        return true;
    }

    public void clearCell(int row, int col) {
        if (!isInitialCell(row, col)) {
            board[row][col] = EMPTY;
        }
    }

    public boolean isPuzzleComplete() {
        // First check if all cells are filled
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == EMPTY) {
                    return false;
                }
            }
        }

        // Then validate the entire board
        return isValidSudoku();
    }

    private boolean isValidSudoku() {
        // Check all rows
        for (int row = 0; row < SIZE; row++) {
            if (!isValidGroup(getRow(row))) {
                return false;
            }
        }

        // Check all columns
        for (int col = 0; col < SIZE; col++) {
            if (!isValidGroup(getColumn(col))) {
                return false;
            }
        }

        // Check all 3x3 boxes
        for (int boxRow = 0; boxRow < 3; boxRow++) {
            for (int boxCol = 0; boxCol < 3; boxCol++) {
                if (!isValidGroup(getBox(boxRow * 3, boxCol * 3))) {
                    return false;
                }
            }
        }

        return true;
    }

    private boolean isValidGroup(int[] group) {
        boolean[] seen = new boolean[10]; // index 0 unused, 1-9 for digits
        for (int num : group) {
            if (num != EMPTY) {
                if (seen[num]) {
                    return false; // Duplicate found
                }
                seen[num] = true;
            }
        }
        return true;
    }

    private int[] getRow(int row) {
        return board[row].clone();
    }

    private int[] getColumn(int col) {
        int[] column = new int[SIZE];
        for (int i = 0; i < SIZE; i++) {
            column[i] = board[i][col];
        }
        return column;
    }

    private int[] getBox(int startRow, int startCol) {
        int[] box = new int[SIZE];
        int index = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                box[index++] = board[startRow + i][startCol + j];
            }
        }
        return box;
    }

    public void solvePuzzle() {
        // Create a copy of the current board to work with
        int[][] workingBoard = new int[SIZE][SIZE];
        copyArray(board, workingBoard);

        if (solveSudoku(workingBoard)) {
            // Only update the board if solution was found
            copyArray(workingBoard, board);
        }
    }

    public int getCell(int row, int col) {
        return board[row][col];
    }

    public boolean isInitialCell(int row, int col) {
        return initialCells[row][col];
    }

    public boolean isEmpty(int row, int col) {
        return board[row][col] == EMPTY;
    }

    private void copyArray(int[][] source, int[][] dest) {
        for (int i = 0; i < SIZE; i++) {
            System.arraycopy(source[i], 0, dest[i], 0, SIZE);
        }
    }

    private void clearArray(int[][] arr) {
        for (int i = 0; i < SIZE; i++) {
            Arrays.fill(arr[i], EMPTY);
        }
    }
}