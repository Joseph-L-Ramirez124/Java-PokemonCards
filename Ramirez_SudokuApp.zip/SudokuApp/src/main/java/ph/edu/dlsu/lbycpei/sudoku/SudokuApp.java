package ph.edu.dlsu.lbycpei.sudoku;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ph.edu.dlsu.lbycpei.sudoku.controller.SudokuController;
import ph.edu.dlsu.lbycpei.sudoku.model.SudokuModel;
import ph.edu.dlsu.lbycpei.sudoku.view.SudokuView;


public class SudokuApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Initialize MVC components
        SudokuModel model = new SudokuModel();
        SudokuView view = new SudokuView();
        SudokuController controller = new SudokuController(model, view);

        // Create and configure scene
        Scene scene = new Scene(view.getRoot(), 512, 640);
        scene.getStylesheets().add(getClass().getResource("/sudoku-styles.css").toExternalForm());

        // Configure stage
        primaryStage.setTitle("LBYCPEI Sudoku Game");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}