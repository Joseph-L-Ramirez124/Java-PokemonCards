package ph.edu.dlsu.lbycpei.sudoku.controller;

import ph.edu.dlsu.lbycpei.sudoku.model.SudokuModel;
import ph.edu.dlsu.lbycpei.sudoku.utils.BackgroundSoundManager;
import ph.edu.dlsu.lbycpei.sudoku.utils.SoundConfig;
import ph.edu.dlsu.lbycpei.sudoku.view.SudokuView;

import javafx.scene.control.TextField;

public class SudokuController {
    private final SudokuModel model;
    private final SudokuView view;
    private final BackgroundSoundManager backgroundSoundManager;

    public SudokuController(SudokuModel model, SudokuView view) {
        this.model = model;
        this.view = view;
        initializeEventHandlers();
        startNewGame();
        backgroundSoundManager = new BackgroundSoundManager();
        playBackgroundMusic(); // Play music
    }

    private void initializeEventHandlers() {
        // New game button
        view.getNewGameButton().setOnAction(e -> startNewGame());

        // Solve button
        view.getSolveButton().setOnAction(e -> solvePuzzle());

        // Check button
        view.getCheckButton().setOnAction(e -> checkPuzzle());

        // Cell input handlers
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                final int row = i;
                final int col = j;
                TextField cell = view.getCell(row, col);

                cell.textProperty().addListener((obs, oldValue, newValue) -> handleCellInput(row, col, newValue));

                cell.setOnKeyPressed(e -> {
                    switch (e.getCode()) {
                        case DELETE:
                        case BACK_SPACE:
                            model.clearCell(row, col);
                            updateView();
                            break;
                    }
                });
            }
        }
    }

    private void handleCellInput(int row, int col, String newValue) {
        if (model.isInitialCell(row, col)) {
            return;
        }

        try {
            if (newValue.isEmpty()) {
                model.clearCell(row, col);
            } else if (newValue.matches("[1-9]")) {
                int num = Integer.parseInt(newValue);
                if (model.isValidMove(row, col, num)) {
                    model.makeMove(row, col, num);
                    view.clearErrors();

                    if (model.isPuzzleComplete()) {
                        view.getStatusLabel().setText("Congratulations! Puzzle completed!");
                        view.getStatusLabel().getStyleClass().add("success-label");
                    } else {
                        view.getStatusLabel().setText("Keep going...");
                        view.getStatusLabel().getStyleClass().remove("success-label");
                    }
                } else {
                    view.highlightError(row, col);
                    view.getStatusLabel().setText("Invalid move! Try again.");
                }
            } else {
                // Invalid input, revert
                updateCellDisplay(row, col);
            }
        } catch (NumberFormatException e) {
            updateCellDisplay(row, col);
        }
    }

    private void startNewGame() {
        String difficulty = view.getDifficultyComboBox().getValue();
        int diffLevel = difficulty.equals("Easy") ? 0 :
                difficulty.equals("Medium") ? 1 : 2;

        model.generatePuzzle(diffLevel);
        updateView();
        view.getStatusLabel().setText("New " + difficulty + " puzzle generated!");
        view.getStatusLabel().getStyleClass().remove("success-label");
    }

    /**
     * Plays the background music for the application in a continuous loop.
     *
     * This method uses the backgroundSoundManager to play the sound file specified
     * for background music in the application's SoundConfig. The music will loop
     * indefinitely until it is explicitly stopped by other means.
     */
    private void playBackgroundMusic() {
        backgroundSoundManager.playLoopingSound(SoundConfig.BACKGROUND_MUSIC);
    }

    private void solvePuzzle() {
        model.solvePuzzle();
        updateView();
        view.getStatusLabel().setText("Puzzle solved!");
    }

    private void updateView() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                int value = model.getCell(i, j);
                boolean isInitial = model.isInitialCell(i, j);
                view.updateCell(i, j, value, isInitial);
            }
        }
    }

    private void updateCellDisplay(int row, int col) {
        int value = model.getCell(row, col);
        view.updateCell(row, col, value, model.isInitialCell(row, col));
    }

    private void checkPuzzle() {
        boolean hasErrors = false;
        view.clearErrors();

        int[][] board = new int[9][9];

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                String text = view.getCell(row, col).getText().trim();
                if (text.matches("[1-9]")) {
                    board[row][col] = Integer.parseInt(text);
                } else {
                    board[row][col] = 0;
                }
            }
        }

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                int num = board[row][col];
                if (num == 0) continue;

                // Check for duplicates in row
                for (int j = 0; j < 9; j++) {
                    if (j != col && board[row][j] == num) {
                        view.highlightError(row, col);
                        view.highlightError(row, j);
                        hasErrors = true;
                    }
                }

                for (int i = 0; i < 9; i++) {
                    if (i != row && board[i][col] == num) {
                        view.highlightError(row, col);
                        view.highlightError(i, col);
                        hasErrors = true;
                    }
                }

                int startRow = (row / 3) * 3;
                int startCol = (col / 3) * 3;
                for (int i = startRow; i < startRow + 3; i++) {
                    for (int j = startCol; j < startCol + 3; j++) {
                        if ((i != row || j != col) && board[i][j] == num) {
                            view.highlightError(row, col);
                            view.highlightError(i, j);
                            hasErrors = true;
                        }
                    }
                }
            }
        }

        if (hasErrors) {
            view.getStatusLabel().setText("Errors found! Check highlighted cells.");
        } else if (model.isPuzzleComplete()) {
            view.getStatusLabel().setText("Perfect! Puzzle completed correctly!");
            view.getStatusLabel().getStyleClass().add("success-label");
        } else {
            view.getStatusLabel().setText("No errors found. Keep going!");
        }
    }

    private boolean isValidPlacement(int row, int col, int num) {
        // Check row
        for (int j = 0; j < 9; j++) {
            if (j != col && model.getCell(row, j) == num) {
                return false;
            }
        }

        // Check column
        for (int i = 0; i < 9; i++) {
            if (i != row && model.getCell(i, col) == num) {
                return false;
            }
        }

        // Check 3x3 box
        int startRow = (row / 3) * 3;
        int startCol = (col / 3) * 3;

        for (int i = startRow; i < startRow + 3; i++) {
            for (int j = startCol; j < startCol + 3; j++) {
                if ((i != row || j != col) && model.getCell(i, j) == num) {
                    return false;
                }
            }
        }

        return true;
    }
}